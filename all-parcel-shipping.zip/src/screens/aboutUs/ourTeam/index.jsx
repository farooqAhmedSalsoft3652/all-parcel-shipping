import { Col, Container, Row } from "react-bootstrap";
import { Team } from "@/assets/images";
import "./index.css";

const OurTeam = () => {
  return (
    <section className="our_team section_padding position-relative two_pices_bg">
      <Container>
        <Row className="align-items-center">
          <Col xs={12}>
            <div className="text-center">
              <h1 className="text-black">About Us</h1>
            </div>
          </Col>
        </Row>
        <Row className="align-items-center">
          <Col lg={6}>
            <div className="Our_img_box">
              <img className="img-fluid" src={Team} alt={true.toString()} />
            </div>
          </Col>
          <Col lg={6}>
            <div className="Our_team_box">
              <h2 className="text-black text-capitalize">Who We Are</h2>
              <p className="d-grey-color">
                Welcome to ACOLAI.com, a platform for people to connect with
                each other and share their experiences and help individuals find
                the right mentor in their industry, hobby, or life.
              </p>
              <ul className="m-0 p-0">
                <li className="my-3 list-unstyled">
                  We believe that mentorship is key to unlocking potential and
                  achieving personal growth, which is why we created a
                  mentor-mentee marketplace that provides a safe space where
                  mentees can have real conversations with great mentors and ask
                  for guidance on important life decisions and expand their
                  growth opportunities.‍
                </li>
                <li className="my-3 list-unstyled">
                  Our founders, Ed and Bradley, have decades of experience in
                  coaching and mentoring individuals. Ed has been thinking about
                  creating a mentorship marketplace for his entire career, and
                  Bradley is a self-taught individual who found success when he
                  found a mentor in Ed. Together, they are two driven
                  individuals with a passion for helping others achieve their
                  goals. They both bring unique perspectives and experiences to
                  the table, making them a dynamic duo. They believe that
                  mentorship is key to unlocking potential and achieving
                  personal growth, and their shared vision and passion for
                  helping others led them to create ACOLAI*.
                </li>
              </ul>
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default OurTeam;
