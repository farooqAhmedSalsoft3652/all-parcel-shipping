import "./index.css";
import Slider from "react-slick";
import { Col, Container, Row } from "react-bootstrap";
import { testimonialcardData } from "@config/data";
import TestimonialCard from "@components/testimonialCard";

const Testimonial = () => {
  const testimonialSliderSettings = {
    dots: true,
    infinite: true,
    speed: 500,
    arrows: false,
    slidesToShow: 2,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    responsive: [
      {
        breakpoint: 1200,
        settings: {
          slidesToShow: 2,
        },
      },
      {
        breakpoint: 992,
        settings: {
          slidesToShow: 1,
        },
      },
      {
        breakpoint: 576,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };

  return (
    <section className="testimonial_sec section_padding">
      <Container>
        <Row>
          <Col xs={12}>
            <div className="text-center">
              <h2 className="text-black text-capitalize">Our Testimonials</h2>
              <p className="d-grey-color">
                Discover what our community says about their transformative mentorship experiences.
              </p>
            </div>
          </Col>
        </Row>
        <Row className="pt-4">
        <Col xs={12}>
          <Slider {...testimonialSliderSettings} className="mySlider">
            {testimonialcardData.map((card) => (
              <div key={card.id} className="px-2">
                <TestimonialCard data={card} />
              </div>
            ))}
          </Slider>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default Testimonial;
