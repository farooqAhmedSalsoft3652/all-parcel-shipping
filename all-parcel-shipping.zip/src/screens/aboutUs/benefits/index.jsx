import "./index.css";
import { useNavigate } from "react-router-dom";
import { Col, Container, Row } from "react-bootstrap";
import { roles } from "@config/data";
import SiteButton from "@components/Button/button";
import useAuth from "@hooks/useAuth";

const Benefits = () => {
  const navigate = useNavigate();
  const { role } = useAuth();
  return (
    <section className="Benefit_section section_padding ">
      <Container>
        <Row>
          <Col lg={10} className="mx-auto order-lg-1 order-2 benifit_Bg position-relative">
            <Row>
              <Col lg={6}>
                <div className="benefit_box bb-1">
                  <p className="num primary_color p-xxl my-4 ">01</p>
                  <h3 className="benefit_heading text-black ">
                    Access To A Diverse Network Of Experienced Mentors
                  </h3>
                  <p className="d-grey-color my-5">
                    When You Join A Community Of Mentors And Mentees, You Have Access To A Diverse Network Of Experienced Mentors Who Can Provide Guidance And Support In A Variety Of Areas. This Can Be Particularly Valuable If You're Looking To Develop New Skills, Transition To A New Career, Or Simply Gain A Different Perspective On Your Personal Or Professional Life.
                  </p>
                </div>
              </Col>
              <Col lg={6}>
                <div className="benefit_box bb-2">
                  <p className="num primary_color p-xxl">02</p>
                  <h3 className="benefit_heading text-black">
                    Opportunities To Build Your Own Leadership Skills
                  </h3>
                  <p className="d-grey-color">
                    As A Mentee, You'll Have The Opportunity To Develop Your Own Leadership Skills By Working With A Mentor Who Can Provide Guidance And Feedback On Your Progress. Additionally, If You Choose To Become A Mentor Yourself, You'll Have The Chance To Develop Your Own Leadership Skills By Helping Others Succeed.
                  </p>
                </div>
                <div className="benefit_box bb-3 mt-3   ">
                  <p className="num primary_color p-xxl">03</p>
                  <h3 className="benefit_heading text-black">
                    Enhanced Sense Of Community And Belonging
                  </h3>
                  <p className="d-grey-color">
                    Joining A Community Of Mentors And Mentees Can Help You Feel More Connected To A Larger Network Of Individuals Who Share Your Interests And Goals. This Can Be Particularly Valuable If You're Feeling Isolated Or Struggling To Find A Sense Of Community In Your Personal Or Professional Life. Being Part Of A Community Can Also Provide A Sense Of Accountability, As You'll Be More Likely To Stay Committed To Your Goals If You Have A Network Of Supporters And Mentors Cheering You On.
                  </p>
                </div>
              </Col>
            </Row>
          </Col>
          <Col lg={6} className="order-lg-2 order-1">
            <div className="benefit">
              <h2 className="section_title">Benefits</h2>
              <p className="d-grey-color">
                Acolai Aims To Provide A One-Stop-Shop For Influencers, Coaches,Mentors And Skilled Professionals A Platform To Showcase Their Talents And Allow For Those Needing Advice, Support Or Direction To Locate Someone Matching Their Needs.
              </p>
              {role.role === roles.mentor ? null : (
                <SiteButton
                  onClick={() => navigate("/featured-ads")}
                  className="site-btn me-3"
                >
                  Find Mentor  
                </SiteButton>
              )}

              <SiteButton
                onClick={() => navigate("/contact-us")}
                className="site-btn site_border_btn"
              >
                Learn More
              </SiteButton>

            </div>
          </Col>
        </Row>
      </Container>
    </section>
  );
};

export default Benefits;
