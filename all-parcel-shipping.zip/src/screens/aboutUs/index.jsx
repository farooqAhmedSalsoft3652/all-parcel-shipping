import Benefits from "./benefits";
import Testimonial from "./testimonial";
import OurTeam from "./ourTeam";
import usePageTitle from "@hooks/usePageTitle";
import { Layout } from "@components/Layout/layout";

const AboutUs = () => {
  usePageTitle("About Us");

  return (
    <>
      <Layout>
        <OurTeam/>
        <Benefits/>
        <Testimonial/>
      </Layout>
    </>
  );
};

export default AboutUs;
