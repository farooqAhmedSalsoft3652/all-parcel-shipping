import "./index.css";
import "react-phone-number-input/style.css";
import axios from "axios";
import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import PhoneInput from "react-phone-number-input";
import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Col, Container, Form, Row } from "react-bootstrap";
import { Select } from 'antd';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowUpFromBracket, faPlus, faArrowLeft } from "@fortawesome/free-solid-svg-icons";
import { faTrashAlt } from "@fortawesome/free-regular-svg-icons";
import { Layout } from "@components/Layout/layout";
import SiteButton from "@components/Button/button";
import CustomModal from "@components/customModal";
import CustomInput from "@components/CustomInput";
import usePageTitle from "@hooks/usePageTitle";
import EducationDetail from "@components/mentorDetail/EducationDetail";
import WorkExperience from "@components/mentorDetail/WorkExperience";
import Certification from "@components/mentorDetail/Certification";

const SignUp = () => {
  usePageTitle("Sign Up");
  const navigate = useNavigate();
  const { state } = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [showModal2, setShowModal2] = useState(false);
  const [value, setValue] = useState();
  const [interests, setInterests] = useState([]);
  const [formData, setFormData] = useState({});
  const [formErrors, setFormErrors] = useState({});
  const [formErrors2, setFormErrors2] = useState({});
  const [profileName1, setProfileName1] = useState("");
  const [profileName2, setProfileName2] = useState("");
  const [load1, setLoad1] = useState(false);
  const [load2, setLoad2] = useState(false);

  const educationFields = {
    id: 1,
    institute_name: "",
    degree_title: "",
    education_from: "",
    education_to: ""
  }
  const workExperienceFields = {
    id: 1,
    organization_name: "",
    designation: "",
    work_from: "",
    work_to: ""
  }
  const certificationFields = {
    id: 1,
    institute_name: "",
    certificate_title: "",
    certificate_picture: "",
  }

  const [education, setEducation] = useState([educationFields]);
  const [workExperience, setWorkExperience] = useState([workExperienceFields]);
  const [certification, setCertification] = useState([certificationFields]);

  const handleNext = (e) => {
    e.preventDefault();
    setCurrentStep(2);
  };

  const handleClick = () => {
    setShowModal(false);
    setShowModal2(false);
    navigate("/login");
  };

  const loadInterest = async () => {
    const options = [];
    let response = await axios.get('/get-interests')
      .then(res => {
        res.data.data.map(item => {
          options.push({
            value: item.name,
            label: item.name
          });
        });
        // console.log(res.data);
        setInterests(options);
      })
      .catch(err => console.error(err.response.data));
  }

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setFormData(() => ({ ...formData, [id]: value }));
  };

  const handleMultipleSelect = (value) => {
    setFormData(() => ({ ...formData, interests: value }));
    // console.log(`Selected: ${value}`);
  };

  const handleBaseImage = (e) => {
    let profile = e.target.files[0];
    setFormData(() => ({ ...formData, profile }));
  }

  const handleDetailFields = (event, itemId, setData) => {
    const { name, value, files } = event.target;
    setData((prevState) => {
      return prevState.map((item) => {
        if (item.id === itemId) {
          return {
            ...item,
            [name]: files !== null ? files[0] : value
          };
        }
        return item;
      });
    });
  };

  useEffect(() => {
    loadInterest();
  }, []);

  const handleMenteeSignup = async (e) => {
    e.preventDefault();
    setLoad1(true);

    if (value) formData.phone_number = value;

    if (formData.other_interests) {
      if (formData.interests) formData.interests.push(formData.other_interests);
      else formData.interests = [formData.other_interests];
      delete formData.other_interests;
    }

    let response = await axios.post('/signup/mentee', formData, {
      headers: { "Content-Type": "multipart/form-data" }
    })
      .then(res => {
        setLoad1(false);
        setShowModal2(true);
        setFormData({});
        setFormErrors2({});
      })
      .catch(err => {
        setLoad1(false);
        setFormErrors2(err.response.data.data);
      });
  }

  const handleMentorSignup = async (e) => {
    e.preventDefault();
    setLoad2(true);

    if (value) formData.phone_number = value;

    if (formData.other_interests) {
      if (formData.interests) formData.interests.push(formData.other_interests);
      else formData.interests = [formData.other_interests];
      delete formData.other_interests;
    }

    if (education.length > 0) formData.education = education;
    if (workExperience.length > 0) formData.work_experience = workExperience;
    if (certification.length > 0) formData.certification = certification;

    let response = await axios.post('/signup/mentor', formData, {
      headers: { "Content-Type": "multipart/form-data" }
    })
      .then(() => {
        setLoad2(false);
        setShowModal(true);
        setFormData({});
        setEducation([educationFields]);
        setWorkExperience([workExperienceFields]);
        setCertification([certificationFields]);
        setFormErrors({});
      })
      .catch(err => {
        setLoad2(false);
        setFormErrors(err.response.data.data);
      });
  }

  const addRow = (setData, data, fields) => {
    setData([...data,
    {
      ...fields,
      id: data.length + 1,
    }
    ]);
  }

  const deleteRow = (setData, data) => {
    const filteredRows = data.filter((row, index) => index !== data.length - 1);
    setData(filteredRows);
  }

  return (
    <>
      <Layout showFooter={false}>
        <section className=" section_padding two_pices_bg position-relative">
          <Container>
            <Row>
              <Col xs={12}>
                <div className="form_layout pb-3">
                  <Row>
                    <Col xs={10} md={10} className="m-auto">
                      <Row>
                        <Col xs={12}>
                          <div className="text-center mt-5">
                            <h3 className="primary_color text-capitalize">
                              Sign Up
                            </h3>
                          </div>
                        </Col>
                      </Row>
                      <Tabs
                        defaultActiveKey={state?.tab ?? "Mentor"}
                        id="uncontrolled-tab-example"
                        className="my-3 sign-up-tab"
                      >
                        <Tab eventKey="Mentor" title="Mentor">
                          <Form onSubmit={handleMentorSignup}>
                            {/* First Step */}
                            {currentStep === 1 && (
                              <>
                                <Row className="pt-4">
                                  <Col md={6} xs={12}>
                                    <CustomInput
                                      label="First Name"
                                      type="text"
                                      id="first_name"
                                      value={formData.first_name}
                                      onChange={handleInputChange}
                                      required
                                      placeholder="Enter First Name"
                                      labelClass="mainLabel bold"
                                      inputClass="mainInput"
                                      inputError={formErrors.first_name}
                                    />
                                  </Col>
                                  <Col md={6} xs={12}>
                                    <CustomInput
                                      label="Last Name"
                                      type="text"
                                      id="last_name"
                                      value={formData.last_name}
                                      onChange={handleInputChange}
                                      required
                                      placeholder="Enter Last Name"
                                      labelClass="mainLabel bold"
                                      inputClass="mainInput"
                                      inputError={formErrors.last_name}
                                    />
                                  </Col>
                                </Row>
                                <Row className="pt-3">
                                  <Col md={6} xs={12}>
                                    <label className="mainLabel bold">
                                      Phone Number
                                      <span className="text-danger">*</span>
                                    </label>
                                    <PhoneInput
                                      placeholder="Enter Phone Number"
                                      value={value}
                                      onChange={setValue}
                                      className="mainInput"
                                      defaultCountry="US"
                                    // focusInputOnCountrySelection="false"
                                    />
                                    {formErrors.phone_number ? (
                                      <small className='text-danger ms-2'>{formErrors.phone_number[0]}</small>
                                    ) : null}
                                  </Col>

                                  <Col md={6} xs={12}>
                                    <CustomInput
                                      label="Email Address"
                                      type="email"
                                      id="email"
                                      value={formData.email}
                                      onChange={handleInputChange}
                                      required
                                      placeholder="Enter Email Address"
                                      labelClass="mainLabel bold"
                                      inputClass="mainInput"
                                      inputError={formErrors.email}
                                    />
                                  </Col>
                                </Row>
                                <Row className="pt-3">
                                  <Col md={6} xs={12}>
                                    <CustomInput
                                      label="New Password"
                                      type="password"
                                      id="password"
                                      value={formData.password}
                                      onChange={handleInputChange}
                                      required
                                      placeholder="Enter New Password"
                                      labelClass="mainLabel bold"
                                      inputClass="mainInput"
                                      inputError={formErrors.password}
                                    />
                                  </Col>

                                  <Col md={6} xs={12}>
                                    <CustomInput
                                      label="Enter Confirm Password"
                                      type="password"
                                      id="confirm_password"
                                      value={formData.confirm_password}
                                      onChange={handleInputChange}
                                      required
                                      placeholder="Confirm Password"
                                      labelClass="mainLabel bold"
                                      inputClass="mainInput"
                                      inputError={formErrors.confirm_password}
                                    />
                                  </Col>
                                </Row>
                                <Row className="pt-3">
                                  <Col md={6} xs={12}>
                                    <div className="fileuploder d-flex justify-content-between align-items-center">
                                      <input
                                        type="file"
                                        id="profile1"
                                        name="profile"
                                        accept="image/*"
                                        className="d-none"
                                        onChange={(e) => {
                                          handleBaseImage(e);
                                          setProfileName1(e.target.files[0].name)
                                        }}
                                      />
                                      <label htmlFor="profile1">
                                        <FontAwesomeIcon
                                          icon={faArrowUpFromBracket}
                                          className="me-2"
                                        />
                                        Upload Profile Photo*
                                      </label>
                                      <small className="text-secondary">{profileName1}</small>
                                    </div>
                                    {formErrors.profile ? (
                                      <small className='text-danger ms-2'>{formErrors.profile[0]}</small>
                                    ) : null}
                                  </Col>
                                </Row>
                              </>
                            )}

                            {/* Second Step */}
                            {currentStep === 2 && (
                              <>
                                {/* ...Your second step form code here... */}
                                {/* personal details Start */}
                                <Row className="pt-4">
                                  <div className="pb-4">
                                    <h3 className="p-xxl primary_color">
                                      <button className="backButton me-2" onClick={() => setCurrentStep(1)}>
                                        <FontAwesomeIcon icon={faArrowLeft} />
                                      </button>
                                      Personal Details
                                    </h3>
                                  </div>
                                  <Col md={6} xs={12}>
                                    <label htmlFor="interests" className="mainLabel bold">
                                      Area Of Interest
                                      <span className="text-danger">*</span>
                                    </label>
                                    <Select
                                      mode="multiple"
                                      // defaultValue="a1"
                                      onChange={handleMultipleSelect}
                                      placeholder="Please select your area of interest"
                                      style={{ width: '100%' }}
                                      options={interests}
                                    />
                                    {formErrors.interests ? (
                                      <small className='text-danger ms-2'>{formErrors.interests[0]}</small>
                                    ) : null}
                                  </Col>
                                  <Col md={6} xs={12}>
                                    <CustomInput
                                      label="Other Interest (If Any)"
                                      type="text"
                                      id="other_interests"
                                      value={formData.other_interests}
                                      onChange={handleInputChange}

                                      placeholder="Enter Other Interest (If Any)"
                                      labelClass="mainLabel bold"
                                      inputClass="mainInput"
                                    />
                                  </Col>
                                  <Col xs={12}>
                                    <label
                                      htmlFor=""
                                      className="mainLabel bold"
                                    >
                                      About Yourself
                                      <span className="text-danger">*</span>
                                    </label>
                                    <textarea
                                      name="about_yourself"
                                      id="about_yourself"
                                      rows="5"
                                      placeholder="About Your Self"
                                      className="mainInput"
                                      value={formData.about_yourself}
                                      onChange={handleInputChange}
                                      required
                                    ></textarea>
                                    {formErrors.about_yourself ? (
                                      <small className='text-danger ms-2'>{formErrors.about_yourself[0]}</small>
                                    ) : null}
                                  </Col>
                                </Row>
                                {/* educational details Start */}
                                <Row className="pt-4">
                                  <Col xs={12}>
                                    <div className="pb-4">
                                      <h3 className="p-xxl primary_color">
                                        Educational Detail
                                      </h3>
                                    </div>
                                  </Col>

                                  {education.map((item, index) => (
                                    <EducationDetail 
                                      key={item.id} 
                                      index={index}
                                      value={item} 
                                      setEducation={setEducation} 
                                      setData={handleDetailFields} 
                                      errors={formErrors}
                                    />
                                  ))}

                                  <Col xs={12}>
                                    <div className="step_btns d-flex justify-content-md-end">
                                      {education.length > 1 && (
                                        <SiteButton 
                                          className="not_Btn primary_color fw-bold" 
                                          onClick={() => deleteRow(setEducation, education)}
                                        >
                                          <FontAwesomeIcon
                                            className="text-danger"
                                            icon={faTrashAlt}
                                          /> Remove
                                        </SiteButton>
                                      )}
                                      <SiteButton 
                                        className="not_Btn primary_color fw-bold" 
                                        onClick={() => addRow(setEducation, education, educationFields)}
                                      >
                                        <FontAwesomeIcon
                                          className="plus_icon"
                                          icon={faPlus}
                                        /> Add More
                                      </SiteButton>
                                    </div>
                                  </Col>
                                </Row>
                                {/* educational details Start */}

                                {/* Work Experience details Start */}
                                <Row className="pt-4">
                                  <Col xs={12}>
                                    <div className="pb-4">
                                      <h3 className="p-xxl primary_color">
                                        Work Experience
                                      </h3>
                                    </div>
                                  </Col>

                                  {workExperience.map((item, index) => (
                                    <WorkExperience 
                                      key={item.id} 
                                      index={index}
                                      value={item}
                                      setWorkExperience={setWorkExperience}
                                      setData={handleDetailFields} 
                                      errors={formErrors}
                                    />
                                  ))}

                                  <Col xs={12}>
                                    <div className="step_btns d-flex justify-content-md-end">
                                      {workExperience.length > 1 && (
                                        <SiteButton 
                                          className="not_Btn primary_color fw-bold" 
                                          onClick={() => deleteRow(setWorkExperience, workExperience)}
                                        >
                                          <FontAwesomeIcon
                                            className="text-danger"
                                            icon={faTrashAlt}
                                          /> Remove
                                        </SiteButton>
                                      )}
                                      <SiteButton 
                                        className="not_Btn primary_color fw-bold" 
                                        onClick={() => addRow(setWorkExperience, workExperience, workExperienceFields)}
                                      >
                                        <FontAwesomeIcon
                                          className="plus_icon"
                                          icon={faPlus}
                                        /> Add More
                                      </SiteButton>
                                    </div>
                                  </Col>
                                </Row>
                                {/* Work Experience details End */}

                                {/* Certification details Start */}
                                <Row className="pt-4">
                                  <Col xs={12}>
                                    <div className="pb-4">
                                      <h3 className="p-xxl primary_color">
                                        Certification Detail
                                      </h3>
                                    </div>
                                  </Col>

                                  {certification.map((item, index) => (
                                    <div className={(index + 1) === certification.length ? '' : 'mb-3'}>
                                      <Row>
                                        <Certification 
                                          key={item.id} 
                                          index={index}
                                          value={item} 
                                          setCertification={setCertification}
                                          setData={handleDetailFields} 
                                          errors={formErrors}
                                        />
                                      </Row>
                                    </div>
                                  ))}
                                  
                                  <Col xs={12}>
                                    <div className="step_btns d-flex justify-content-md-end">
                                      {certification.length > 1 && (
                                        <SiteButton 
                                          className="not_Btn primary_color fw-bold" 
                                          onClick={() => deleteRow(setCertification, certification)}
                                        >
                                          <FontAwesomeIcon
                                            className="text-danger"
                                            icon={faTrashAlt}
                                          /> Remove
                                        </SiteButton>
                                      )}
                                      <SiteButton 
                                        className="not_Btn primary_color fw-bold" 
                                        onClick={() => addRow(setCertification, certification, certificationFields)}
                                      >
                                        <FontAwesomeIcon
                                          className="plus_icon"
                                          icon={faPlus}
                                        /> Add More
                                      </SiteButton>
                                    </div>
                                  </Col>
                                </Row>
                                {/* Certification details End */}
                                <Row className="my-5 text-center">
                                  <Col xs={12}>
                                    <SiteButton
                                      type="submit"
                                      className="site-btn"
                                      load={load2}
                                    >
                                      Register
                                    </SiteButton>
                                  </Col>
                                </Row>
                              </>
                            )}

                            {/* Next Button */}
                            {currentStep === 1 && (
                              <Row className="my-5 text-center">
                                <Col xs={12}>
                                  <SiteButton
                                    type="submit"
                                    className="site-btn"
                                    onClick={handleNext}
                                  >
                                    Next
                                  </SiteButton>
                                  <div className="mt-3">
                                    <p className="fw-bold text-black">
                                      Already Have An Account?
                                      <span className="ms-2">
                                        <Link
                                          className="text-decoration-none"
                                          to="/Login"
                                        >
                                          Login
                                        </Link>
                                      </span>
                                    </p>
                                  </div>
                                </Col>
                              </Row>
                            )}
                          </Form>
                        </Tab>
                        <Tab eventKey="Mentee" title="Mentee">
                          <div id="response"></div>
                          <Form onSubmit={handleMenteeSignup}>
                            <>
                              <Row className="pt-4">
                                <Col md={6} xs={12}>
                                  <CustomInput
                                    label="First Name"
                                    type="text"
                                    id="first_name"
                                    value={formData.first_name}
                                    onChange={handleInputChange}
                                    required
                                    placeholder="Enter First Name"
                                    labelClass="mainLabel bold"
                                    inputClass="mainInput"
                                    inputError={formErrors2.first_name}
                                  />
                                </Col>
                                <Col md={6} xs={12}>
                                  <CustomInput
                                    label="Last Name"
                                    type="text"
                                    id="last_name"
                                    value={formData.last_name}
                                    onChange={handleInputChange}
                                    required
                                    placeholder="Enter Last Name"
                                    labelClass="mainLabel bold"
                                    inputClass="mainInput"
                                    inputError={formErrors2.last_name}
                                  />
                                </Col>
                              </Row>
                              <Row className="pt-3">
                                <Col md={6} xs={12}>
                                  <label className="mainLabel bold">
                                    Phone Number
                                    <span className="text-danger">*</span>
                                  </label>
                                  <PhoneInput
                                    placeholder="Enter phone number"
                                    value={value}
                                    onChange={setValue}
                                    id="phone_number"
                                    name="phone_number"
                                    className="mainInput"
                                    defaultCountry="US"
                                  // focusInputOnCountrySelection="false"
                                  />
                                  {formErrors2.phone_number ? (
                                    <small className='text-danger ms-2'>{formErrors2.phone_number[0]}</small>
                                  ) : null}
                                </Col>
                                <Col lg={6} xs={12}>
                                  <label htmlFor="interests" className="mainLabel bold d-block">
                                    Area Of Interest
                                    <span className="text-danger">*</span>
                                  </label>
                                  <Select
                                    mode="multiple"
                                    // defaultValue="a1"
                                    id="interests"
                                    onChange={handleMultipleSelect}
                                    placeholder="Please select your area of interest"
                                    style={{ width: '100%' }}
                                    options={interests}
                                  />
                                  {formErrors2.interests ? (
                                    <small className='text-danger ms-2'>{formErrors2.interests[0]}</small>
                                  ) : null}
                                </Col>
                                <Col md={6} xs={12} className="pt-4">
                                  <CustomInput
                                    label="Other Interest (If Any)"
                                    type="text"
                                    id="other_interests"
                                    value={formData.other_interests}
                                    onChange={handleInputChange}
                                    placeholder="Other Interest (If Any)"
                                    labelClass="mainLabel bold"
                                    inputClass="mainInput"
                                    inputError={formErrors2.other_interests}
                                  />
                                </Col>
                                <Col md={6} xs={12} className="pt-4">
                                  <CustomInput
                                    label="Email Address"
                                    type="email"
                                    id="email"
                                    value={formData.email}
                                    onChange={handleInputChange}
                                    required
                                    placeholder="Enter Email Address"
                                    labelClass="mainLabel bold"
                                    inputClass="mainInput"
                                    inputError={formErrors2.email}
                                  />
                                </Col>
                                <Col xs={12}>
                                  <label
                                    htmlFor="aboutYourself"
                                    className="mainLabel bold"
                                  >
                                    About Yourself
                                    <span className="text-danger">*</span>
                                  </label>
                                  <textarea
                                    name="about_yourself"
                                    id="about_yourself"
                                    rows="5"
                                    placeholder="About Your Self"
                                    className="mainInput"
                                    value={formData.aboutYourself}
                                    onChange={handleInputChange}
                                    required
                                  ></textarea>
                                  {formErrors2.about_yourself ? (
                                    <div className="mb-3">
                                      <small className='text-danger ms-2'>{formErrors2.about_yourself[0]}</small>
                                    </div>
                                  ) : null}
                                </Col>
                              </Row>
                              <Row >
                                <Col md={6} xs={12}>
                                  <CustomInput
                                    label="New Password"
                                    type="password"
                                    id="password"
                                    value={formData.password}
                                    onChange={handleInputChange}
                                    required
                                    placeholder="Enter New Password"
                                    labelClass="mainLabel bold"
                                    inputClass="mainInput"
                                    inputError={formErrors2.password}
                                  />
                                </Col>

                                <Col md={6} xs={12}>
                                  <CustomInput
                                    label="Confirm Password"
                                    type="password"
                                    id="confirm_password"
                                    value={formData.confirm_password}
                                    onChange={handleInputChange}
                                    required
                                    placeholder="Confirm Password"
                                    labelClass="mainLabel bold"
                                    inputClass="mainInput"
                                    inputError={formErrors2.confirm_password}
                                  />
                                </Col>
                              </Row>
                              <Row className="pt-3">
                                <Col md={6} xs={12}>
                                  <div className="fileuploder d-flex justify-content-between align-items-center">
                                    <input
                                      type="file"
                                      id="profile2"
                                      name="profile"
                                      accept="image/*"
                                      className="d-none"
                                      onChange={(e) => {
                                        handleBaseImage(e);
                                        setProfileName2(e.target.files[0].name)
                                      }}
                                    />
                                    <label htmlFor="profile2">
                                      <FontAwesomeIcon
                                        icon={faArrowUpFromBracket}
                                        className="me-2"
                                      />
                                      Upload Profile Photo*
                                    </label>
                                    <small className="text-secondary">{profileName2}</small>
                                  </div>
                                  {formErrors2.profile ? (
                                    <small className='text-danger ms-2'>{formErrors2.profile[0]}</small>
                                  ) : null}
                                </Col>
                              </Row>
                            </>
                            <Row className="my-5 text-center">
                              <Col xs={12}>
                                <SiteButton type="submit" className="site-btn" load={load1}>Register</SiteButton>
                                <div className="mt-3">
                                  <p className="fw-bold text-black">
                                    Already Have An Account?
                                    <span className="ms-2">
                                      <Link className=" text-decoration-none" to="/login">
                                        Login
                                      </Link>
                                    </span>
                                  </p>
                                </div>
                              </Col>
                            </Row>
                          </Form>
                        </Tab>
                      </Tabs>
                    </Col>
                  </Row>
                </div>
              </Col>
            </Row>
          </Container>
        </section>
      </Layout>

      <CustomModal
        show={showModal}
        close={() => setShowModal(false)}
        onClickOk={handleClick}
        success
        para="Profile has been created successfully. Please wait for the admin approval."
      />
      <CustomModal
        show={showModal2}
        close={() => setShowModal2(false)}
        onClickOk={handleClick}
        success
        para="Profile Created Successfully"
      />
    </>
  );
};

export default SignUp;
