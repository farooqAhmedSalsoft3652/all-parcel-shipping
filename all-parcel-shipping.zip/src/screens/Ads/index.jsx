import "./index.css";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Container, Row, Col } from "react-bootstrap";
import { roles } from "@config/data";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faSearch } from "@fortawesome/free-solid-svg-icons";
import { Layout } from "@components/Layout/layout";
import SiteButton from "@components/Button/button";
import CustomModal from "@components/customModal";
import FeaturedCard from "@components/featuredCard";
import LoadingSpinner from "@components/loader";
import CustomPagination from "@components/customPagination";
import usePageTitle from "@hooks/usePageTitle";
import useAuth from "@hooks/useAuth";
import axios from "axios";


const AdsPage = () => {
  usePageTitle("Ads");
  const navigate = useNavigate();
  const { role } = useAuth();
  const [ads, setAds] = useState([]);
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalRecords, setTotalRecords] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [showLoginButton, setShowLoginButton] = useState(true);
  const [load, setLoad] = useState(true);

  const handleLogin = () => {
    navigate("/login");
  };

  const loadAds = async (search = null) => {
    let url = `/home/get-ads?type=ads&page=${currentPage}`;
    if(search) url += `&search=${search}`;
    
    let data = await axios.get(url)
        .then(response => {
          let total_records    = response.data.data.meta.total;
          let records_per_page = response.data.data.meta.per_page;
          let total_pages      = Math.ceil(total_records / records_per_page);

          setAds(response.data.data.data);
          setCurrentPage(response.data.data.meta.current_page);
          setTotalRecords(total_records);
          setTotalPages(total_pages);
          setLoad(false);
        })
        .catch(err => console.error(err.response.data));
  }

  useEffect(() => {
    setLoad(true);
    const timeoutId = setTimeout(() => loadAds(search), 500);
    return () => clearTimeout(timeoutId);
  }, [search, currentPage]);

  return (
    <>
      <Layout>
        <section className="featured_ads pt-5 position-relative fA_bg">
          <Container>
            <Row className="text-center">
              <Col xs={12}>
                <div className="text-center">
                  <h1 className="text-black text-capitalize">Ads</h1>
                  <p className="d-grey-color">
                    Connect with top-tier mentors who empower your success.<br />Exceptional insights and support await in our featured mentorships.
                  </p>
                </div>
                <div className="searchWrapper ">
                  <input
                    type="text"
                    name="search"
                    placeholder="Search"
                    className="filterInput-Search"
                    onChange={e => setSearch(e.target.value)}
                  />
                  <button className="searchButton2 notButton">
                    <FontAwesomeIcon icon={faSearch} />
                  </button>
                </div>
              </Col>
            </Row>
            <Row className="mt-4">
              {load ? (
                <LoadingSpinner />
              ) : (
              ads.map((card) => (
                <Col key={card.id} sm={6} lg={3} className="px-2 pt-3">
                  {role.role === roles.mentor ? (
                    <FeaturedCard data={card} />
                  ) : role.role === roles.mentee ? (
                    <Link
                      className="text-decoration-none list-unstyled"
                      to={`/mentor/details/${card.id}`}
                    >
                      <FeaturedCard data={card} />
                    </Link>
                  ) : (
                    <SiteButton
                      onClick={() => setShowModal(true)}
                      type="button"
                      className="not_Btn"
                    >
                      <FeaturedCard data={card} />
                    </SiteButton>
                  )}
                </Col>
              )))}
            </Row>

            <Row className="justify-content-between">
              <Col xs={12}>
                <CustomPagination
                  currentPage={currentPage}
                  setCurrentPage={setCurrentPage}
                  totalPages={totalPages}
                  totalRecords={totalRecords}
                />
              </Col>
            </Row>
          </Container>
        </section>
      </Layout>

      <CustomModal
        show={showModal}
        close={() => setShowModal(false)}
        para="To View The Complete Detail Of The Mentor You Will Need To Login Or Signup First"
        success={false}
        handleLogin={handleLogin}
        showLoginButton={showLoginButton}
      />
    </>
  );
};

export default AdsPage;
