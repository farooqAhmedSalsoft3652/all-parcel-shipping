import "./index.css";
import { Container, Row, Col } from "react-bootstrap";
import FeaturedCard from "@components/featuredCard";
import { Link, useNavigate } from "react-router-dom";
import SiteButton from "@components/Button/button";
import AdCard from "@components/mentorCard/adCard";
import { pmScales, pmScreen, pmLaptop, pmBoxLabel } from "../../../assets/images";


const leftData = [
  {
    title: "Abc Ad 1",
    description: "Ad Title",
  },
  {
    title: "10/01/2023",
    description: "Subscription Date",
  },
 
  {
    title: "20",
    description: "Requests Received",
  },
  {
    title: "40",
    description: "Remaining Requests",
  },
];
const rightData = [
  {
    title: "Abc Ad 1",
    description: "Ad Title",
  },
  {
    title: "10/01/2023",
    description: "Subscription Date",
  },
 
  {
    title: "20",
    description: "Requests Received",
  },
  {
    title: "40",
    description: "Remaining Requests",
  },
];


const HomePackages = (props) => {

  return (
    <>
    <section className="pad-top-4 pad-bottom-4 color-bg-oompa-light">
      <Container>
          <Row>
              <Col xs={12}>
                  <h3 className="h2 t-center font-size-5 color-text-berry">Lorem ipsum dolor sit amet</h3>
                  <div className="home-steps push-bottom-4 js-animate-in-view">
                      <div className="home-steps__item">
                          <div className="home-steps__img">
                              <img src={pmScales} width="230" height="230" alt={true.toString()} />
                          </div>
                          <div className="home-steps__content">
                              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque, </p>
                          </div>
                      </div>
                      <div className="home-steps__item">
                          <div className="home-steps__img">
                              <img src={pmScreen} width="230" height="230" alt={true.toString()} />
                          </div>
                          <div className="home-steps__content">
                              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque, </p>
                          </div>
                      </div>
                      <div className="home-steps__item">
                          <div className="home-steps__img">
                              <img src={pmLaptop} width="230" height="230" alt={true.toString()} />
                          </div>
                          <div className="home-steps__content">
                              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque, </p>
                          </div>
                      </div>
                      <div className="home-steps__item">
                          <div className="home-steps__img">
                              <img src={pmBoxLabel} width="230" height="230" alt={true.toString()} />
                          </div>
                          <div className="home-steps__content">
                              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cumque, </p>
                          </div>
                      </div>
                  </div>
                  <div className="grid medium-width-6 h-center t-center">
                      <a className="btn btn--quarternary btn--ghosted color-bg-white " href="#_">Try our shipping calculator</a>
                  </div>
              </Col>
          </Row>
      </Container>
    </section>
    </>
  );
};

export default HomePackages;
