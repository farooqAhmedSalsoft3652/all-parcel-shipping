import "./index.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Col, Container, Row } from "react-bootstrap";
import SiteButton from "@components/Button/button";
import { services1, services2, services3, services4 } from "../../../assets/images";

const Services = () => {
  const [showSignUpButton, setShowSignUpButton] = useState(true);
  return (
    <>
      <section className="pad-top-4 pad-bottom-6 color-bg-berry-darker oh js-animate-in-view">
        <Container>
          <Row>
            <Col xs={12}>
              <h3 className="h2 t-center font-size-5 color-text-white">
                Lorem ipsum dolor sit amet consectetur
              </h3>
              <div className="grid push-bottom-1">
                <div className="grid-item large-width-6 js-animate-in-view">
                  <div className="info-block">
                    <div className="info-block__img">
                      <img width="250" height="250" src={services1} alt={true.toString()} />
                    </div>
                    <div className="info-block__content">
                      <div className="info-block__title">Lorem ipsum dolor</div>
                      <div className="info-block__text">
                        Lorem ipsum dolor sit amet consectetur
                      </div>
                    </div>
                  </div>
                </div>
                <div className="grid-item large-width-6 js-animate-in-view">
                  <div className="info-block">
                    <div className="info-block__img">
                      <img width="250" height="250" src={services2} alt={true.toString()} />
                    </div>
                    <div className="info-block__content">
                      <div className="info-block__title">Lorem ipsum dolor</div>
                      <div className="info-block__text">
                        Lorem ipsum dolor sit amet consectetur
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="grid push-bottom-4">
                <div className="grid-item large-width-6 js-animate-in-view">
                  <div className="info-block">
                    <div className="info-block__img">
                      <img width="250" height="250" src={services3} alt={true.toString()} />
                    </div>
                    <div className="info-block__content">
                      <div className="info-block__title">Lorem ipsum dolor</div>
                      <div className="info-block__text">
                        Lorem ipsum dolor sit amet consectetur
                      </div>
                    </div>
                  </div>
                </div>
                <div className="grid-item large-width-6 js-animate-in-view">
                  <div className="info-block">
                    <div className="info-block__img">
                      <img width="250" height="250" src={services4} alt={true.toString()} />
                    </div>
                    <div className="info-block__content">
                      <div className="info-block__title">Lorem ipsum dolor</div>
                      <div className="info-block__text">
                        Lorem ipsum dolor sit amet consectetur
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="medium-width-6 t-center h-center">
                {/* <SiteButton onClick={() => navigate("/contact-us")} className="site-btn site_border_btn">See more delivery services</SiteButton>; */}
                <a className="btn btn--secondary " href="#_">
                  See more delivery services
                </a>
              </div>
            </Col>
          </Row>
        </Container>
      </section>
    </>
  );
};

export default Services;


 